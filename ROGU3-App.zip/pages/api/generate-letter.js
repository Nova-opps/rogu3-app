import { OpenAI } from 'openai';

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const { prompt, tone } = req.body;
  if (!prompt || !tone) return res.status(400).json({ error: 'Missing prompt or tone' });

  const systemPrompt = `You are an AI letter-writing assistant. Your job is to write hilarious, poetic, or savagely creative grudge letters based on user complaints. The tone should match one of the following:
  - Shakespearean Insult
  - Corporate Clapback
  - Victorian Rage
  - Teen Drama
  - AI Savage Mode`;

  const userPrompt = `Write a grudge letter in the tone of "${tone}" about: ${prompt}`;

  try {
    const completion = await openai.chat.completions.create({
      model: 'gpt-4',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt }
      ],
      temperature: 0.9,
      max_tokens: 600
    });

    const letter = completion.choices[0].message.content;
    res.status(200).json({ letter });
  } catch (err) {
    console.error('OpenAI Error:', err);
    res.status(500).json({ error: 'Failed to generate letter' });
  }
}
