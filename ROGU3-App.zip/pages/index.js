import React, { useState } from 'react';
import Head from 'next/head';

export default function Home() {
  const [prompt, setPrompt] = useState('');
  const [tone, setTone] = useState('Shakespearean Insult');
  const [letter, setLetter] = useState('');
  const [loading, setLoading] = useState(false);

  const generateLetter = async () => {
    setLoading(true);
    const res = await fetch('/api/generate-letter', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt, tone })
    });
    const data = await res.json();
    setLetter(data.letter);
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-white p-6">
      <Head>
        <title>ROGU3</title>
        <link rel="manifest" href="/manifest.json" />
        <meta name="theme-color" content="#ff0000" />
        <meta name="description" content="Unleash the power within" />
      </Head>
      <h1 className="text-4xl text-red-500 font-bold text-center mb-4">ROGU3 🔥</h1>
      <p className="text-center text-zinc-400 mb-6">Unleash the power within</p>
      <textarea
        value={prompt}
        onChange={(e) => setPrompt(e.target.value)}
        placeholder="Who wronged you today?"
        className="w-full bg-zinc-800 p-4 rounded-lg mb-4 text-white"
        rows={4}
      />
      <select
        value={tone}
        onChange={(e) => setTone(e.target.value)}
        className="w-full p-2 mb-4 bg-zinc-800 border-zinc-700 text-white rounded"
      >
        {['Shakespearean Insult', 'Corporate Clapback', 'Victorian Rage', 'Teen Drama', 'AI Savage Mode'].map(t => (
          <option key={t}>{t}</option>
        ))}
      </select>
      <button
        onClick={generateLetter}
        disabled={loading}
        className="w-full bg-red-600 p-2 rounded hover:bg-red-700"
      >
        {loading ? 'Writing...' : 'Generate Letter'}
      </button>
      {letter && <div className="mt-6 whitespace-pre-wrap bg-zinc-900 p-4 rounded-lg border border-red-500">{letter}</div>}
    </div>
  );
}
